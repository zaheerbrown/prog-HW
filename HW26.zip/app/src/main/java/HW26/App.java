import java.util.Scanner;

public class MergeSortedLists {

    // Method to merge two sorted lists into a new sorted list
    public static int[] merge(int[] list1, int[] list2) {
        int length1 = list1.length;
        int length2 = list2.length;
        int[] mergedList = new int[length1 + length2];
        
        int i = 0, j = 0, k = 0;

        // Merge both lists
        while (i < length1 && j < length2) {
            if (list1[i] <= list2[j]) {
                mergedList[k++] = list1[i++];
            } else {
                mergedList[k++] = list2[j++];
            }
        }

        // Copy remaining elements of list1 if any
        while (i < length1) {
            mergedList[k++] = list1[i++];
        }

        // Copy remaining elements of list2 if any
        while (j < length2) {
            mergedList[k++] = list2[j++];
        }

        return mergedList;
    }

    // Test program
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Read first sorted list
        System.out.println("Enter the number of elements in the first sorted list:");
        int size1 = input.nextInt();
        int[] list1 = new int[size1];
        System.out.println("Enter the elements of the first sorted list:");
        for (int i = 0; i < size1; i++) {
            list1[i] = input.nextInt();
        }

        // Read second sorted list
        System.out.println("Enter the number of elements in the second sorted list:");
        int size2 = input.nextInt();
        int[] list2 = new int[size2];
        System.out.println("Enter the elements of the second sorted list:");
        for (int i = 0; i < size2; i++) {
            list2[i] = input.nextInt();
        }

        // Merge the lists
        int[] mergedList = merge(list1, list2);

        // Display the merged list
        System.out.println("Merged list:");
        for (int num : mergedList) {
            System.out.print(num + " ");
        }
        System.out.println();

        input.close();
    }
}
