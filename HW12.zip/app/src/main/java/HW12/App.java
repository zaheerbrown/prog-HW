import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;

public class RandomNumberGenerator {

    // Method to return a random number between 1 and 54 excluding specified numbers
    public static int getRandom(int... numbers) {
        HashSet<Integer> excludedNumbers = new HashSet<>();
        for (int num : numbers) {
            excludedNumbers.add(num);
        }

        Random rand = new Random();
        int randomNum;
        do {
            randomNum = rand.nextInt(54) + 1; // Generates a number between 1 and 54
        } while (excludedNumbers.contains(randomNum));

        return randomNum;
    }

    // Test program
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter numbers to exclude (space-separated): ");
        String[] inputStrings = input.nextLine().split(" ");
        int[] excludedNumbers = new int[inputStrings.length];
        for (int i = 0; i < inputStrings.length; i++) {
            excludedNumbers[i] = Integer.parseInt(inputStrings[i]);
        }

        // Get and display a random number excluding the specified numbers
        int randomNum = getRandom(excludedNumbers);
        System.out.println("Random number (excluding specified numbers): " + randomNum);
    }
}
