import java.util.Scanner;

public class CheckSorted {

    // Method to check if the array is sorted in increasing order
    public static boolean isSorted(int[] list) {
        for (int i = 1; i < list.length; i++) {
            if (list[i - 1] > list[i]) {
                return false;
            }
        }
        return true;
    }

    // Test program
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the number of elements in the list:");
        int numberOfElements = input.nextInt();

        int[] list = new int[numberOfElements];

        System.out.println("Enter the elements of the list:");
        for (int i = 0; i < numberOfElements; i++) {
            list[i] = input.nextInt();
        }

        // Check if the list is sorted
        boolean sorted = isSorted(list);

        // Display the result
        if (sorted) {
            System.out.println("The list is already sorted.");
        } else {
            System.out.println("The list is not sorted.");
        }
    }
}
