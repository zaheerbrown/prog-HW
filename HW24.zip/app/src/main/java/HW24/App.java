import java.util.Random;

public class CardSum {

    // Method to compute the value of a card based on its rank
    private static int getCardValue(String card) {
        switch (card) {
            case "Ace": return 1;
            case "Jack": return 11;
            case "Queen": return 12;
            case "King": return 13;
            default: return Integer.parseInt(card); // for numbers 2 to 10
        }
    }

    public static void main(String[] args) {
        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        String[] ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};
        String[] deck = new String[52];

        // Create the deck of cards
        int index = 0;
        for (String suit : suits) {
            for (String rank : ranks) {
                deck[index++] = rank + " of " + suit;
            }
        }

        Random random = new Random();
        int count = 0;

        // Simulate picking four cards and checking their sum
        while (true) {
            // Shuffle the deck
            for (int i = 0; i < deck.length; i++) {
                int randomIndex = random.nextInt(deck.length);
                String temp = deck[i];
                deck[i] = deck[randomIndex];
                deck[randomIndex] = temp;
            }

            // Pick four cards
            int sum = 0;
            for (int i = 0; i < 4; i++) {
                String card = deck[i];
                sum += getCardValue(card.split(" ")[0]); // Get the card value
            }

            if (sum == 24) {
                count++;
                System.out.println("Found a valid pick:");
                for (int i = 0; i < 4; i++) {
                    System.out.println(deck[i]);
                }
                System.out.println("Sum: " + sum);
                break; // Exit after finding one valid combination
            }
        }

        // Display the result
        System.out.println("Number of picks yielding a sum of 24: " + count);
    }
}
