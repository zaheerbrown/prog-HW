import java.util.Scanner;

public class ReverseArray {

    // Method to reverse the array
    public static double[] reverse(double[] array) {
        int n = array.length;
        for (int i = 0; i < n / 2; i++) {
            double temp = array[i];
            array[i] = array[n - 1 - i];
            array[n - 1 - i] = temp;
        }
        return array;
    }

    // Test program
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double[] numbers = new double[10];

        System.out.println("Enter ten numbers: ");
        for (int i = 0; i < 10; i++) {
            numbers[i] = input.nextDouble();
        }

        // Reverse the array
        reverse(numbers);

        // Display the reversed array
        System.out.println("The reversed array is: ");
        for (double number : numbers) {
           
