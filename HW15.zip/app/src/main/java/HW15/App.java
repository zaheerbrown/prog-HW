import java.util.Scanner;
import java.util.Arrays;
import java.util.Comparator;

public class StudentScores {

    // Class to store student name and score
    static class Student {
        String name;
        int score;

        Student(String name, int score) {
            this.name = name;
            this.score = score;
        }
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Prompt user for the number of students
        System.out.print("Enter the number of students: ");
        int numberOfStudents = input.nextInt();
        input.nextLine(); // Consume newline character

        // Create an array to hold the students
        Student[] students = new Student[numberOfStudents];

        // Prompt user for each student's name and score
        for (int i = 0; i < numberOfStudents; i++) {
            System.out.print("Enter the name of student " + (i + 1) + ": ");
            String name = input.nextLine();
            System.out.print("Enter the score of student " + (i + 1) + ": ");
            int score = input.nextInt();
            input.nextLine(); // Consume newline character

            students[i] = new Student(name, score);
        }

        // Sort the students array in decreasing order of scores
        Arrays.sort(students, new Comparator<Student>() {
            public int compare(Student s1, Student s2) {
                return Integer.compare(s2.score, s1.score);
            }
        });

        // Print student names in decreasing order of their scores
        System.out.println("Student names in decreasing order of their scores:");
        for (Student student : students) {
            System.out.println(student.name + ": " + student.score);
        }
    }
}
