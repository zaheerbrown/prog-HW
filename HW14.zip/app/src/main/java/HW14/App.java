import java.util.Scanner;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

public class EliminateDuplicates {

    // Method to eliminate duplicate values from the array
    public static int[] eliminateDuplicates(int[] list) {
        Set<Integer> set = new LinkedHashSet<>();
        for (int num : list) {
            set.add(num);
        }
        int[] result = new int[set.size()];
        int index = 0;
        for (int num : set) {
            result[index++] = num;
        }
        return result;
    }

    // Test program
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] numbers = new int[10];

        System.out.println("Enter ten integers: ");
        for (int i = 0; i < 10; i++) {
            numbers[i] = input.nextInt();
        }

        // Eliminate duplicates and display the result
        int[] uniqueNumbers = eliminateDuplicates(numbers);
        System.out.println("The array after eliminating duplicates: " + Arrays.toString(uniqueNumbers));
    }
}
