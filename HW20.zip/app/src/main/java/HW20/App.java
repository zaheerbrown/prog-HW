import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class CardCollector {

    // Define the suits and ranks of a standard deck of cards
    private static final String[] SUITS = {"Hearts", "Diamonds", "Clubs", "Spades"};
    private static final String[] RANKS = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};

    public static void main(String[] args) {
        // Create a list to represent a shuffled deck of cards
        ArrayList<String> deck = new ArrayList<>();
        Random random = new Random();
        Map<String, ArrayList<String>> suitMap = new HashMap<>();
        int[] suitCounters = new int[SUITS.length];
        
        // Initialize the deck with all cards
        for (String suit : SUITS) {
            for (String rank : RANKS) {
                deck.add(rank + " of " + suit);
                suitMap.put(rank + " of " + suit, new ArrayList<>());
            }
        }

        // Shuffle the deck
        Collections.shuffle(deck);

        // Initialize counters for the number of cards picked
        int totalPicks = 0;
        while (true) {
            String card = deck.get(random.nextInt(deck.size()));
            totalPicks++;
            
            // Determine the suit of the picked card
            String suit = card.split(" of ")[1];
            
            // Add the card to the corresponding suit list
            suitMap.get(card).add(card);
            int suitIndex = getIndexOfSuit(suit);
            suitCounters[suitIndex]++;
            
            // Check if we have four cards for each suit
            boolean allSuitsComplete = true;
            for (int count : suitCounters) {
                if (count < 4) {
                    allSuitsComplete = false;
                    break;
                }
            }
            
            if (allSuitsComplete) {
                break;
            }
        }

        // Display the results
        System.out.println("Total picks needed: " + totalPicks);
        for (String suit : SUITS) {
            System.out.println(suit + " cards picked:");
            for (String card : suitMap.values()) {
                if (card.get(0).split(" of ")[1].equals(suit)) {
                    System.out.print(card + " ");
                }
            }
            System.out.println();
        }
    }
    
    // Helper method to get the index of the suit
    private static int getIndexOfSuit(String suit) {
        for (int i = 0; i < SUITS.length; i++) {
            if (SUITS[i].equals(suit)) {
                return i;
            }
        }
        return -1; // Should never happen
    }
}
