import java.util.Arrays;
import java.util.Scanner;

public class SortString {

    // Method to sort the characters of a string
    public static String sort(String s) {
        // Convert string to character array
        char[] characters = s.toCharArray();
        
        // Sort the character array
        Arrays.sort(characters);
        
        // Convert the sorted character array back to string
        return new String(characters);
    }

    // Test program
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Prompt the user to enter a string
        System.out.println("Enter a string to sort:");
        String userInput = input.nextLine();

        // Sort the string
        String sortedString = sort(userInput);

        // Display the sorted string
        System.out.println("Sorted string:");
        System.out.println(sortedString);

        input.close();
    }
}
