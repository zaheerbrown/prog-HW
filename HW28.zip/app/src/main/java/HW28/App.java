import java.util.Random;
import java.util.Scanner;

public class HangmanGame {
    // Array of words to choose from
    private static final String[] WORDS = {"java", "programming", "hangman", "challenge", "developer"};

    // Method to get a random word from the array
    private static String getRandomWord() {
        Random random = new Random();
        return WORDS[random.nextInt(WORDS.length)];
    }

    // Method to play a single game of Hangman
    private static void playGame() {
        Scanner input = new Scanner(System.in);
        String word = getRandomWord();
        char[] hiddenWord = new char[word.length()];
        for (int i = 0; i < word.length(); i++) {
            hiddenWord[i] = '*';
        }
        
        int misses = 0;
        boolean gameFinished = false;
        boolean[] guessedLetters = new boolean[26]; // Track guessed letters

        while (!gameFinished) {
            System.out.println("Current word: " + new String(hiddenWord));
            System.out.println("Misses: " + misses);
            System.out.println("Guess a letter:");
            char guess = input.next().toLowerCase().charAt(0);
            
            // Check if letter has already been guessed
            if (guess < 'a' || guess > 'z' || guessedLetters[guess - 'a']) {
                System.out.println("Invalid or already guessed letter.");
                continue;
            }
            
            guessedLetters[guess - 'a'] = true;
            
            boolean correctGuess = false;
            // Reveal guessed letter in the hiddenWord
            for (int i = 0; i < word.length(); i++) {
                if (word.charAt(i) == guess) {
                    hiddenWord[i] = guess;
                    correctGuess = true;
                }
            }
            
            if (!correctGuess) {
                misses++;
            }
            
            // Check if the game is finished
            if (new String(hiddenWord).equals(word)) {
                System.out.println("Congratulations! You've guessed the word: " + word);
                System.out.println("Total misses: " + misses);
                gameFinished = true;
            }
        }
    }

    // Main method to run the game
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        boolean continuePlaying = true;

        while (continuePlaying) {
            playGame();
            System.out.println("Do you want to play again? (yes/no)");
            String response = input.next().toLowerCase();
            if (!response.equals("yes")) {
                continuePlaying = false;
                System.out.println("Thanks for playing!");
            }
        }

        input.close();
    }
}
