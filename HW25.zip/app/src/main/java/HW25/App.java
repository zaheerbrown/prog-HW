import java.util.Scanner;

public class ConsecutiveCheck {

    // Method to check if the array has four consecutive numbers with the same value
    public static boolean isConsecutiveFour(int[] values) {
        // Iterate through the array
        for (int i = 0; i <= values.length - 4; i++) {
            // Check if the next four elements are the same
            if (values[i] == values[i + 1] && values[i] == values[i + 2] && values[i] == values[i + 3]) {
                return true;
            }
        }
        return false;
    }

    // Test program
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Prompt user to enter the number of values
        System.out.println("Enter the number of values in the series:");
        int size = input.nextInt();

        // Create an array to hold the values
        int[] values = new int[size];

        // Prompt user to enter the values
        System.out.println("Enter the values:");
        for (int i = 0; i < size; i++) {
            values[i] = input.nextInt();
        }

        // Check if the array contains four consecutive identical numbers
        boolean hasConsecutiveFour = isConsecutiveFour(values);

        // Display the result
        if (hasConsecutiveFour) {
            System.out.println("The series contains four consecutive numbers with the same value.");
        } else {
            System.out.println("The series does not contain four consecutive numbers with the same value.");
        }

        input.close();
    }
}
