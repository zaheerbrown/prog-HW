 import java.util.Scanner;

public class ListEqualityChecker {

    // Method to check if two arrays are strictly identical
    public static boolean equals(int[] list1, int[] list2) {
        // Check if the arrays have the same length
        if (list1.length != list2.length) {
            return false;
        }
        
        // Check if all corresponding elements are equal
        for (int i = 0; i < list1.length; i++) {
            if (list1[i] != list2[i]) {
                return false;
            }
        }
        
        return true;
    }

    // Test program
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Read first list
        System.out.println("Enter the number of elements for the first list:");
        int size1 = input.nextInt();
        int[] list1 = new int[size1];
        System.out.println("Enter the elements of the first list:");
        for (int i = 0; i < size1; i++) {
            list1[i] = input.nextInt();
        }

        // Read second list
        System.out.println("Enter the number of elements for the second list:");
        int size2 = input.nextInt();
        int[] list2 = new int[size2];
        System.out.println("Enter the elements of the second list:");
        for (int i = 0; i < size2; i++) {
            list2[i] = input.nextInt();
        }

        // Check if the lists are strictly identical
        boolean areIdentical = equals(list1, list2);
        
        // Display the result
        if (areIdentical) {
            System.out.println("The two lists are strictly identical.");
        } else {
            System.out.println("The two lists are not strictly identical.");
        }
    }
}
