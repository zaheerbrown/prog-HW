import java.util.Scanner;

public class StudentGrades {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Prompt the user to enter the total number of students
        System.out.print("Enter the number of students: ");
        int numberOfStudents = input.nextInt();

        // Create an array to hold the scores
        int[] scores = new int[numberOfStudents];

        // Prompt the user to enter the scores
        System.out.println("Enter the scores:");
        for (int i = 0; i < numberOfStudents; i++) {
            scores[i] = input.nextInt();
        }

        // Find the best score
        int best = findBestScore(scores);

        // Assign and display grades
        assignGrades(scores, best);

        input.close();
    }

    // Method to find the best score
    public static int findBestScore(int[] scores) {
        int best = scores[0];
        for (int score : scores) {
            if (score > best) {
                best = score;
            }
        }
        return best;
    }

    // Method to assign and display grades
    public static void assignGrades(int[] scores, int best) {
        for (int i = 0; i < scores.length; i++) {
            int score = scores[i];
            char grade;

            if (score >= best - 10) {
                grade = 'A';
            } else if (score >= best - 20) {
                grade = 'B';
            } else if (score >= best - 30) {
                grade = 'C';
            } else if (score >= best - 40) {
                grade = 'D';
            } else {
                grade = 'F';
            }

            System.out.println("Student " + i + " score is " + score + " and grade is " + grade);
        }
    }
}
