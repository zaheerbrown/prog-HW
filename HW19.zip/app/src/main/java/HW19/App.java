public class LockerProblem {

    public static void main(String[] args) {
        // Number of lockers and students
        final int TOTAL_LOCKERS = 100;
        
        // Array to keep track of the state of each locker (false = closed, true = open)
        boolean[] lockers = new boolean[TOTAL_LOCKERS];
        
        // Iterate over each student
        for (int student = 1; student <= TOTAL_LOCKERS; student++) {
            // Each student toggles the lockers according to their number
            for (int locker = student; locker <= TOTAL_LOCKERS; locker += student) {
                lockers[locker - 1] = !lockers[locker - 1]; // Toggle the locker state
            }
        }
        
        // Collect and display the numbers of open lockers
        System.out.print("Open lockers: ");
        for (int i = 0; i < TOTAL_LOCKERS; i++) {
            if (lockers[i]) {
                System.out.print((i + 1) + " "); // Display the locker number (1-based index)
            }
        }
    }
}
