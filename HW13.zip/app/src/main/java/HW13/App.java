import java.util.Scanner;

public class GCDCalculator {

    // Method to calculate the GCD of an unspecified number of integers
    public static int gcd(int... numbers) {
        if (numbers == null || numbers.length == 0) {
            throw new IllegalArgumentException("At least one number is required");
        }

        int gcd = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            gcd = gcd(gcd, numbers[i]);
        }

        return gcd;
    }

    // Helper method to calculate the GCD of two integers using the Euclidean algorithm
    private static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    // Test program
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] numbers = new int[5];

        System.out.println("Enter five numbers: ");
        for (int i = 0; i < 5; i++) {
            numbers[i] = input.nextInt();
        }

        // Calculate and display the GCD
        int resultGCD = gcd(numbers);
        System.out.println("The GCD of the entered numbers is: " + resultGCD);
    }
}
