import java.util.Scanner;

public class BubbleSort {

    // Method to perform bubble sort on an array of doubles
    public static void bubbleSort(double[] array) {
        int n = array.length;
        boolean swapped;
        do {
            swapped = false;
            for (int i = 1; i < n; i++) {
                if (array[i - 1] > array[i]) {
                    // Swap the elements
                    double temp = array[i - 1];
                    array[i - 1] = array[i];
                    array[i] = temp;
                    swapped = true;
                }
            }
            // After each pass, the largest element is in its correct position
            n--;
        } while (swapped);
    }

    // Test program
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double[] numbers = new double[10];

        System.out.println("Enter ten double numbers: ");
        for (int i = 0; i < 10; i++) {
            numbers[i] = input.nextDouble();
        }

        // Sort the array using bubble sort
        bubbleSort(numbers);

        // Display the sorted array
        System.out.println("The sorted numbers are: ");
        for (double number : numbers) {
            System.out.print(number + " ");
        }
    }
}
